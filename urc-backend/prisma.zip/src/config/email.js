// // Email configuration placeholder
// module.exports = {
//   from: 'no-reply@example.com'
// };

// src/config/email.js
// Sets up the Nodemailer transporter using Gmail SMTP

const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host:   process.env.EMAIL_HOST   || 'smtp.gmail.com',
  port:   parseInt(process.env.EMAIL_PORT) || 587,
  secure: process.env.EMAIL_SECURE === 'true',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
  tls: {
    // Do not fail on invalid certs in development
    rejectUnauthorized: process.env.NODE_ENV === 'production',
  },
});

// Test connection when the server starts
transporter.verify()
  .then(() => console.log('✅  Email service connected'))
  .catch((err) => console.error('❌  Email connection failed:', err.message));

module.exports = transporter;
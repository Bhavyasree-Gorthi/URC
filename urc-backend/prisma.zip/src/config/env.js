// // Environment variable validation placeholder
// module.exports = {
//   port: process.env.PORT || 3000,
// };

// src/config/env.js
// Validates all required environment variables on startup
// If any are missing, the server will NOT start

const required = [
  'DATABASE_URL',
  'JWT_ACCESS_SECRET',
  'JWT_REFRESH_SECRET',
  'EMAIL_HOST',
  'EMAIL_PORT',
  'EMAIL_USER',
  'EMAIL_PASS',
  'EMAIL_FROM',
  'FRONTEND_URL',
];

const missing = required.filter((key) => !process.env[key]);

if (missing.length > 0) {
  console.error('❌  Missing required environment variables:');
  missing.forEach((key) => console.error(`   - ${key}`));
  console.error('\nPlease add them to your .env file and restart.');
  process.exit(1);
}

module.exports = {
  DATABASE_URL:               process.env.DATABASE_URL,
  JWT_ACCESS_SECRET:          process.env.JWT_ACCESS_SECRET,
  JWT_REFRESH_SECRET:         process.env.JWT_REFRESH_SECRET,
  JWT_ACCESS_EXPIRES:         process.env.JWT_ACCESS_EXPIRES  || '15m',
  JWT_REFRESH_EXPIRES:        process.env.JWT_REFRESH_EXPIRES || '7d',
  EMAIL_HOST:                 process.env.EMAIL_HOST,
  EMAIL_PORT:                 parseInt(process.env.EMAIL_PORT),
  EMAIL_SECURE:               process.env.EMAIL_SECURE === 'true',
  EMAIL_USER:                 process.env.EMAIL_USER,
  EMAIL_PASS:                 process.env.EMAIL_PASS,
  EMAIL_FROM:                 process.env.EMAIL_FROM,
  FRONTEND_URL:               process.env.FRONTEND_URL,
  PORT:                       parseInt(process.env.PORT) || 3001,
  NODE_ENV:                   process.env.NODE_ENV || 'development',
  BCRYPT_ROUNDS:              parseInt(process.env.BCRYPT_ROUNDS) || 12,
  RESET_TOKEN_EXPIRES_MINS:   parseInt(process.env.RESET_TOKEN_EXPIRES_MINS)  || 30,
  VERIFY_TOKEN_EXPIRES_HOURS: parseInt(process.env.VERIFY_TOKEN_EXPIRES_HOURS) || 24,
};
// // Rate limiter middleware placeholder
// module.exports = (req, res, next) => { next(); };

// src/middleware/rateLimiter.js
// Protects endpoints from brute-force attacks and spam

const rateLimit = require('express-rate-limit');

// ── Login: 10 attempts per 15 minutes per IP ───────────────────
exports.authLimiter = rateLimit({
  windowMs:        15 * 60 * 1000,
  max:             10,
  message:         { error: 'Too many login attempts. Please try again in 15 minutes.' },
  standardHeaders: true,
  legacyHeaders:   false,
});

// ── Register: 5 registrations per hour per IP ──────────────────
exports.registerLimiter = rateLimit({
  windowMs:        60 * 60 * 1000,
  max:             5,
  message:         { error: 'Too many registrations from this IP. Please try again later.' },
  standardHeaders: true,
  legacyHeaders:   false,
});

// ── Password reset: 3 requests per hour per IP ─────────────────
exports.resetLimiter = rateLimit({
  windowMs:        60 * 60 * 1000,
  max:             3,
  message:         { error: 'Too many password reset requests. Please try again in 1 hour.' },
  standardHeaders: true,
  legacyHeaders:   false,
});

// ── General API: 200 requests per 15 minutes per IP ───────────
exports.generalLimiter = rateLimit({
  windowMs:        15 * 60 * 1000,
  max:             200,
  message:         { error: 'Too many requests. Please slow down.' },
  standardHeaders: true,
  legacyHeaders:   false,
});
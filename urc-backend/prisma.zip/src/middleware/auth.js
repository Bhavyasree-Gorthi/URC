// // JWT verification middleware placeholder
// module.exports = (req, res, next) => { next(); };
// src/middleware/auth.js
// Verifies JWT access token on every protected route

const jwt = require('jsonwebtoken');

// ── Authenticate — verifies Bearer token ───────────────────────
exports.authenticate = (req, res, next) => {
  const header = req.headers.authorization;

  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required. Please log in.' });
  }

  const token = header.split(' ')[1];

  try {
    req.user = jwt.verify(token, process.env.JWT_ACCESS_SECRET);
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({
        error: 'Your session has expired. Please log in again.',
        code:  'TOKEN_EXPIRED',
      });
    }
    return res.status(401).json({ error: 'Invalid token. Please log in again.' });
  }
};

// ── Require Admin role ──────────────────────────────────────────
exports.requireAdmin = (req, res, next) => {
  if (req.user?.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Admin access required.' });
  }
  next();
};
// // Global error handler placeholder
// module.exports = (err, req, res, next) => {
//   console.error(err);
//   res.status(500).json({ error: 'Internal server error' });
// };

// src/middleware/errorHandler.js
// Global error handler — catches all unhandled errors

const errorHandler = (err, req, res, next) => {
  console.error('🔴 Server Error:', err);

  // Prisma unique constraint violation (e.g. duplicate email)
  if (err.code === 'P2002') {
    return res.status(409).json({
      error: `A record with this ${err.meta?.target?.join(', ')} already exists.`,
    });
  }

  // Prisma record not found
  if (err.code === 'P2025') {
    return res.status(404).json({ error: 'Record not found.' });
  }

  // JWT errors
  if (err.name === 'JsonWebTokenError') {
    return res.status(401).json({ error: 'Invalid token.' });
  }
  if (err.name === 'TokenExpiredError') {
    return res.status(401).json({ error: 'Token expired.', code: 'TOKEN_EXPIRED' });
  }

  // Default server error
  res.status(err.status || 500).json({
    error: process.env.NODE_ENV === 'production'
      ? 'Internal server error. Please try again.'
      : err.message,
  });
};

module.exports = errorHandler;
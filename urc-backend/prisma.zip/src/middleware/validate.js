// // Input validation middleware (express-validator) placeholder
// module.exports = (req, res, next) => { next(); };

// src/middleware/validate.js
// Input validation using express-validator

const { body, param, validationResult } = require('express-validator');

// ── Run validators and return errors if any ────────────────────
const handle = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error:  'Validation failed',
      errors: errors.array().map((e) => ({ field: e.path, message: e.msg })),
    });
  }
  next();
};

// ── Register validation ────────────────────────────────────────
exports.validateRegister = [
  body('name')
    .trim()
    .notEmpty().withMessage('Name is required')
    .isLength({ min: 2, max: 100 }).withMessage('Name must be 2–100 characters'),

  body('email')
    .isEmail().withMessage('A valid email address is required')
    .normalizeEmail(),

  body('password')
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
    .matches(/[A-Z]/).withMessage('Password must contain at least one uppercase letter')
    .matches(/[0-9]/).withMessage('Password must contain at least one number'),

  body('regiment')
    .trim()
    .notEmpty().withMessage('Regiment / Unit is required'),

  handle,
];

// ── Login validation ───────────────────────────────────────────
exports.validateLogin = [
  body('email')
    .isEmail().withMessage('Valid email required')
    .normalizeEmail(),

  body('password')
    .notEmpty().withMessage('Password is required'),

  handle,
];

// ── Password reset validation ──────────────────────────────────
exports.validateResetPassword = [
  body('password')
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
    .matches(/[A-Z]/).withMessage('Password must contain at least one uppercase letter')
    .matches(/[0-9]/).withMessage('Password must contain at least one number'),

  handle,
];

// ── Create booking validation ──────────────────────────────────
exports.validateCreateBooking = [
  body('slotId')
    .notEmpty().withMessage('Slot ID is required'),

  body('category')
    .isIn(['GROCERY', 'LIQUOR_ONLY', 'GROCERY_AND_LIQUOR'])
    .withMessage('Category must be GROCERY, LIQUOR_ONLY, or GROCERY_AND_LIQUOR'),

  handle,
];
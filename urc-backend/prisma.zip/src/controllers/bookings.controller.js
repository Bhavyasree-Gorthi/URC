// // Bookings controller placeholder
// exports.create = (req, res) => res.json({});

// src/controllers/bookings.controller.js

const prisma       = require('../utils/prisma');
const emailService = require('../services/email.service');
const auditService = require('../services/audit.service');

// Generate token number: TKN-2401, TKN-2402 ...
const genTokenNo = async () => {
  const count = await prisma.booking.count();
  return `TKN-${String(2400 + count + 1).padStart(4, '0')}`;
};

// ══════════════════════════════════════
// GET MY BOOKINGS
// GET /api/bookings/mine
// ══════════════════════════════════════
exports.getMyBookings = async (req, res) => {
  try {
    const bookings = await prisma.booking.findMany({
      where:   { userId: req.user.userId },
      include: {
        slot: true,
        user: { select: { name: true, email: true, memberId: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json(bookings);
  } catch (err) {
    console.error('Get bookings error:', err);
    res.status(500).json({ error: 'Failed to fetch bookings.' });
  }
};

// ══════════════════════════════════════
// CREATE BOOKING
// POST /api/bookings
// ══════════════════════════════════════
exports.createBooking = async (req, res) => {
  try {
    const { slotId, category } = req.body;
    const userId               = req.user.userId;

    // Verify slot exists
    const slot = await prisma.slot.findUnique({ where: { id: slotId } });
    if (!slot)          return res.status(404).json({ error: 'Slot not found.' });
    if (slot.disabled)  return res.status(400).json({ error: 'This slot is disabled.' });
    if (slot.holiday)   return res.status(400).json({ error: 'This is a holiday slot.' });
    if (slot.booked >= slot.capacity) {
      return res.status(400).json({ error: 'This slot is fully booked.' });
    }

    // One booking per user per date
    const sameDay = await prisma.booking.findFirst({
      where: {
        userId,
        status: 'ACTIVE',
        slot:   { date: slot.date },
      },
    });
    if (sameDay) {
      return res.status(400).json({ error: 'You already have a booking on this date.' });
    }

    const tokenNo = await genTokenNo();

    // Create booking + increment slot count atomically
    const [booking] = await prisma.$transaction([
      prisma.booking.create({
        data:    { tokenNo, userId, slotId, category, status: 'ACTIVE' },
        include: { slot: true, user: true },
      }),
      prisma.slot.update({
        where: { id: slotId },
        data:  { booked: { increment: 1 } },
      }),
    ]);

    // Send confirmation email (non-blocking — don't await)
    emailService
      .sendBookingConfirmation(booking.user, booking, booking.slot)
      .catch(console.error);

    auditService.log({ action: 'BOOKING_CREATED', userId, req, meta: { tokenNo } });

    res.status(201).json(booking);
  } catch (err) {
    console.error('Create booking error:', err);
    res.status(500).json({ error: 'Booking failed. Please try again.' });
  }
};

// ══════════════════════════════════════
// CANCEL BOOKING
// PATCH /api/bookings/:id/cancel
// ══════════════════════════════════════
exports.cancelBooking = async (req, res) => {
  try {
    const booking = await prisma.booking.findUnique({
      where:   { id: req.params.id },
      include: { slot: true, user: true },
    });

    if (!booking) {
      return res.status(404).json({ error: 'Booking not found.' });
    }

    // Only the booking owner or an admin can cancel
    if (booking.userId !== req.user.userId && req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'You are not authorized to cancel this booking.' });
    }

    if (booking.status !== 'ACTIVE') {
      return res.status(400).json({ error: 'Only active bookings can be cancelled.' });
    }

    // Cancel booking + decrement slot count atomically
    const [updated] = await prisma.$transaction([
      prisma.booking.update({
        where: { id: req.params.id },
        data:  {
          status:      'CANCELLED',
          cancelledBy: req.user.userId,
        },
      }),
      prisma.slot.update({
        where: { id: booking.slotId },
        data:  { booked: { decrement: 1 } },
      }),
    ]);

    // Send cancellation email (non-blocking)
    emailService
      .sendBookingCancelledEmail(booking.user, booking, booking.slot)
      .catch(console.error);

    auditService.log({
      action:  'BOOKING_CANCELLED',
      userId:  req.user.userId,
      req,
      meta:    { tokenNo: booking.tokenNo, cancelledFor: booking.userId },
    });

    res.json({ message: 'Booking cancelled successfully.', booking: updated });
  } catch (err) {
    console.error('Cancel booking error:', err);
    res.status(500).json({ error: 'Cancellation failed. Please try again.' });
  }
};
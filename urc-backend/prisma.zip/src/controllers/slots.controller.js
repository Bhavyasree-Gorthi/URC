// // Slots controller placeholder
// exports.list = (req, res) => res.json([]);

// src/controllers/slots.controller.js

const prisma = require('../utils/prisma');

// ══════════════════════════════════════
// GET ALL SLOTS
// GET /api/slots  or  /api/slots?date=2024-01-15
// ══════════════════════════════════════
exports.getSlots = async (req, res) => {
  try {
    const { date } = req.query;
    const where    = date ? { date: new Date(date) } : {};

    const slots = await prisma.slot.findMany({
      where,
      orderBy: [{ date: 'asc' }, { time: 'asc' }],
    });

    res.json(slots);
  } catch (err) {
    console.error('Get slots error:', err);
    res.status(500).json({ error: 'Failed to fetch slots.' });
  }
};

// ══════════════════════════════════════
// GET SLOTS FOR NEXT 14 DAYS
// GET /api/slots/upcoming
// ══════════════════════════════════════
exports.getUpcomingSlots = async (req, res) => {
  try {
    const today   = new Date();
    today.setHours(0, 0, 0, 0);
    const in14Days = new Date(today);
    in14Days.setDate(today.getDate() + 14);

    const slots = await prisma.slot.findMany({
      where: {
        date: { gte: today, lte: in14Days },
      },
      orderBy: [{ date: 'asc' }, { time: 'asc' }],
    });

    res.json(slots);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch upcoming slots.' });
  }
};

// ══════════════════════════════════════
// UPDATE SLOT (Admin only)
// PUT /api/admin/slots/:id
// ══════════════════════════════════════
exports.updateSlot = async (req, res) => {
  try {
    const { capacity, disabled, holiday } = req.body;

    const slot = await prisma.slot.update({
      where: { id: req.params.id },
      data: {
        ...(capacity !== undefined && { capacity: parseInt(capacity) }),
        ...(disabled !== undefined && { disabled: Boolean(disabled) }),
        ...(holiday  !== undefined && { holiday:  Boolean(holiday) }),
      },
    });

    res.json(slot);
  } catch (err) {
    console.error('Update slot error:', err);
    res.status(500).json({ error: 'Failed to update slot.' });
  }
};

// ══════════════════════════════════════
// CREATE SLOTS FOR NEXT 14 DAYS (Admin)
// POST /api/admin/slots/generate
// ══════════════════════════════════════
exports.generateSlots = async (req, res) => {
  try {
    const times    = ['09:00 AM','10:00 AM','11:00 AM','12:00 PM','02:00 PM','03:00 PM','04:00 PM'];
    const capacity = req.body.capacity || 20;
    const today    = new Date();
    today.setHours(0, 0, 0, 0);
    const created  = [];

    for (let d = 0; d < 14; d++) {
      const date = new Date(today);
      date.setDate(today.getDate() + d);

      for (const time of times) {
        // upsert — skip if already exists
        const slot = await prisma.slot.upsert({
          where:  { date_time: { date, time } },
          update: {},
          create: { date, time, capacity },
        });
        created.push(slot);
      }
    }

    res.json({ message: `Generated ${created.length} slots for the next 14 days.`, count: created.length });
  } catch (err) {
    console.error('Generate slots error:', err);
    res.status(500).json({ error: 'Failed to generate slots.' });
  }
};
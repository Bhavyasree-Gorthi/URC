// // Auth controller placeholder
// exports.login = (req, res) => res.json({});

// src/controllers/auth.controller.js
// Handles: register, login, logout, email verify, forgot/reset password, refresh token

const bcrypt       = require('bcryptjs');
const crypto       = require('crypto');
const prisma       = require('../utils/prisma');
const tokenService = require('../services/token.service');
const emailService = require('../services/email.service');
const auditService = require('../services/audit.service');

// ── Helpers ────────────────────────────────────────────────────
const genRawToken  = () => crypto.randomBytes(32).toString('hex');
const hashToken    = (t) => crypto.createHash('sha256').update(t).digest('hex');
const genMemberId  = async () => {
  const count = await prisma.user.count();
  return `URC-${String(count + 1).padStart(4, '0')}`;
};

// ══════════════════════════════════════
// REGISTER
// POST /api/auth/register
// ══════════════════════════════════════
exports.register = async (req, res) => {
  try {
    const { name, email, password, regiment, phone } = req.body;

    // Check if email already registered
    const exists = await prisma.user.findUnique({ where: { email } });
    if (exists) {
      return res.status(409).json({ error: 'This email is already registered.' });
    }

    const passwordHash = await bcrypt.hash(
      password,
      parseInt(process.env.BCRYPT_ROUNDS || 12)
    );
    const memberId = await genMemberId();

    const user = await prisma.user.create({
      data: {
        name,
        email,
        passwordHash,
        regiment,
        phone: phone || null,
        memberId,
        status: 'PENDING',
        emailVerified: false,
      },
    });

    // Create email verification token
    const rawToken    = genRawToken();
    const hashedToken = hashToken(rawToken);
    const hours       = parseInt(process.env.VERIFY_TOKEN_EXPIRES_HOURS || 24);

    await prisma.emailVerification.create({
      data: {
        userId:    user.id,
        token:     hashedToken,
        expiresAt: new Date(Date.now() + hours * 60 * 60 * 1000),
      },
    });

    // Send verification email (non-blocking)
    emailService.sendVerificationEmail(user, rawToken).catch(console.error);

    auditService.log({ action: 'REGISTER', userId: user.id, req });

    res.status(201).json({
      message:  'Registration successful! Please check your email to verify your account.',
      memberId,
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Registration failed. Please try again.' });
  }
};

// ══════════════════════════════════════
// LOGIN
// POST /api/auth/login
// ══════════════════════════════════════
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await prisma.user.findUnique({ where: { email } });

    // Check if account is locked
    if (user?.lockedUntil && user.lockedUntil > new Date()) {
      const mins = Math.ceil((user.lockedUntil - Date.now()) / 60000);
      auditService.log({ action: 'LOGIN_LOCKED', userId: user.id, req, success: false });
      return res.status(423).json({
        error: `Account temporarily locked. Please try again in ${mins} minute(s).`,
      });
    }

    const valid = user && await bcrypt.compare(password, user.passwordHash);

    if (!valid) {
      // Track failed attempts
      if (user) {
        const attempts = user.loginAttempts + 1;
        if (attempts >= 5) {
          await prisma.user.update({
            where: { id: user.id },
            data:  { loginAttempts: 0, lockedUntil: new Date(Date.now() + 15 * 60 * 1000) },
          });
          auditService.log({ action: 'LOGIN_FAIL_LOCKED', userId: user.id, req, success: false });
          return res.status(423).json({
            error: 'Too many failed attempts. Account locked for 15 minutes.',
          });
        }
        await prisma.user.update({
          where: { id: user.id },
          data:  { loginAttempts: attempts },
        });
      }
      auditService.log({ action: 'LOGIN_FAIL', userId: user?.id, req, success: false });
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // Check email verified
    if (!user.emailVerified) {
      return res.status(403).json({
        error: 'Please verify your email address first. Check your inbox.',
        code:  'EMAIL_NOT_VERIFIED',
      });
    }

    // Check account status
    if (user.status === 'PENDING') {
      return res.status(403).json({
        error: 'Your account is pending admin approval. You will be notified by email.',
        code:  'PENDING',
      });
    }
    if (user.status === 'DISABLED' || user.status === 'SUSPENDED') {
      return res.status(403).json({
        error: 'Your account has been disabled. Please contact the administrator.',
        code:  'DISABLED',
      });
    }

    // Reset failed login attempts on success
    await prisma.user.update({
      where: { id: user.id },
      data:  { loginAttempts: 0, lockedUntil: null, lastLoginAt: new Date() },
    });

    // Generate token pair
    const { accessToken, refreshToken } = await tokenService.generateTokenPair(user, req);

    // Set refresh token as httpOnly cookie (7 days)
    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure:   process.env.NODE_ENV === 'production',
      sameSite: 'Strict',
      maxAge:   7 * 24 * 60 * 60 * 1000,
    });

    auditService.log({ action: 'LOGIN', userId: user.id, req });

    res.json({
      accessToken,
      user: {
        id:       user.id,
        name:     user.name,
        email:    user.email,
        role:     user.role,
        regiment: user.regiment,
        memberId: user.memberId,
        status:   user.status,
      },
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Login failed. Please try again.' });
  }
};

// ══════════════════════════════════════
// VERIFY EMAIL
// GET /api/auth/verify-email/:token
// ══════════════════════════════════════
exports.verifyEmail = async (req, res) => {
  try {
    const hashedToken = hashToken(req.params.token);

    const record = await prisma.emailVerification.findFirst({
      where: {
        token:     hashedToken,
        used:      false,
        expiresAt: { gt: new Date() },
      },
    });

    if (!record) {
      return res.status(400).json({
        error: 'This verification link is invalid or has expired. Please request a new one.',
      });
    }

    // Mark email as verified + mark token as used (transaction)
    await prisma.$transaction([
      prisma.user.update({
        where: { id: record.userId },
        data:  { emailVerified: true, emailVerifiedAt: new Date() },
      }),
      prisma.emailVerification.update({
        where: { id: record.id },
        data:  { used: true },
      }),
    ]);

    auditService.log({ action: 'EMAIL_VERIFIED', userId: record.userId, req });

    // Redirect to frontend with success flag
    res.redirect(`${process.env.FRONTEND_URL}?verified=true`);
  } catch (err) {
    console.error('Email verify error:', err);
    res.status(500).json({ error: 'Email verification failed.' });
  }
};

// ══════════════════════════════════════
// RESEND VERIFICATION EMAIL
// POST /api/auth/resend-verification
// ══════════════════════════════════════
exports.resendVerification = async (req, res) => {
  try {
    const { email } = req.body;
    const user = await prisma.user.findUnique({ where: { email } });

    if (!user || user.emailVerified) {
      return res.json({ message: 'If that email exists and is unverified, a new link has been sent.' });
    }

    // Invalidate old tokens
    await prisma.emailVerification.updateMany({
      where: { userId: user.id, used: false },
      data:  { used: true },
    });

    const rawToken    = genRawToken();
    const hashedToken = hashToken(rawToken);
    const hours       = parseInt(process.env.VERIFY_TOKEN_EXPIRES_HOURS || 24);

    await prisma.emailVerification.create({
      data: {
        userId:    user.id,
        token:     hashedToken,
        expiresAt: new Date(Date.now() + hours * 60 * 60 * 1000),
      },
    });

    emailService.sendVerificationEmail(user, rawToken).catch(console.error);

    res.json({ message: 'If that email exists and is unverified, a new link has been sent.' });
  } catch (err) {
    res.status(500).json({ error: 'Request failed. Please try again.' });
  }
};

// ══════════════════════════════════════
// FORGOT PASSWORD
// POST /api/auth/forgot-password
// ══════════════════════════════════════
exports.forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;
    const user = await prisma.user.findUnique({ where: { email } });

    // Always return the same response to prevent email enumeration
    const successMsg = { message: 'If that email is registered, a reset link has been sent.' };
    if (!user) return res.json(successMsg);

    // Invalidate any existing reset tokens
    await prisma.passwordReset.updateMany({
      where: { userId: user.id, used: false },
      data:  { used: true },
    });

    const rawToken    = genRawToken();
    const hashedToken = hashToken(rawToken);
    const mins        = parseInt(process.env.RESET_TOKEN_EXPIRES_MINS || 30);

    await prisma.passwordReset.create({
      data: {
        userId:    user.id,
        token:     hashedToken,
        expiresAt: new Date(Date.now() + mins * 60 * 1000),
      },
    });

    emailService.sendPasswordResetEmail(user, rawToken).catch(console.error);

    auditService.log({ action: 'PASSWORD_RESET_REQUEST', userId: user.id, req });

    res.json(successMsg);
  } catch (err) {
    console.error('Forgot password error:', err);
    res.status(500).json({ error: 'Request failed. Please try again.' });
  }
};

// ══════════════════════════════════════
// RESET PASSWORD
// POST /api/auth/reset-password/:token
// ══════════════════════════════════════
exports.resetPassword = async (req, res) => {
  try {
    const hashedToken = hashToken(req.params.token);

    const record = await prisma.passwordReset.findFirst({
      where: {
        token:     hashedToken,
        used:      false,
        expiresAt: { gt: new Date() },
      },
    });

    if (!record) {
      return res.status(400).json({
        error: 'This reset link is invalid or has expired. Please request a new one.',
      });
    }

    const passwordHash = await bcrypt.hash(
      req.body.password,
      parseInt(process.env.BCRYPT_ROUNDS || 12)
    );

    // Update password + mark token used + delete all sessions (force re-login everywhere)
    await prisma.$transaction([
      prisma.user.update({
        where: { id: record.userId },
        data:  { passwordHash, loginAttempts: 0, lockedUntil: null },
      }),
      prisma.passwordReset.update({
        where: { id: record.id },
        data:  { used: true },
      }),
      prisma.session.deleteMany({ where: { userId: record.userId } }),
    ]);

    auditService.log({ action: 'PASSWORD_RESET_SUCCESS', userId: record.userId, req });

    res.json({ message: 'Password reset successful! You can now log in with your new password.' });
  } catch (err) {
    console.error('Reset password error:', err);
    res.status(500).json({ error: 'Password reset failed. Please try again.' });
  }
};

// ══════════════════════════════════════
// REFRESH TOKEN
// POST /api/auth/refresh-token
// ══════════════════════════════════════
exports.refreshToken = async (req, res) => {
  try {
    const token = req.cookies.refreshToken;
    if (!token) {
      return res.status(401).json({ error: 'No refresh token found. Please log in.' });
    }
    const accessToken = await tokenService.refreshAccessToken(token);
    res.json({ accessToken });
  } catch (err) {
    res.clearCookie('refreshToken');
    res.status(401).json({ error: 'Session expired. Please log in again.' });
  }
};

// ══════════════════════════════════════
// LOGOUT
// POST /api/auth/logout
// ══════════════════════════════════════
exports.logout = async (req, res) => {
  try {
    const token = req.cookies.refreshToken;
    if (token) {
      await prisma.session.deleteMany({ where: { refreshToken: token } });
    }
    res.clearCookie('refreshToken');
    auditService.log({ action: 'LOGOUT', userId: req.user?.userId, req });
    res.json({ message: 'Logged out successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'Logout failed.' });
  }
};
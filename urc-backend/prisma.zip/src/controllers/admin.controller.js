// // Admin controller placeholder
// exports.stats = (req, res) => res.json({});
// src/controllers/admin.controller.js

const prisma       = require('../utils/prisma');
const emailService = require('../services/email.service');
const auditService = require('../services/audit.service');

// ══════════════════════════════════════
// GET ALL USERS
// GET /api/admin/users
// ══════════════════════════════════════
exports.getAllUsers = async (req, res) => {
  try {
    const users = await prisma.user.findMany({
      select: {
        id:           true,
        memberId:     true,
        name:         true,
        email:        true,
        regiment:     true,
        role:         true,
        status:       true,
        emailVerified:true,
        lastLoginAt:  true,
        createdAt:    true,
        _count: {
          select: { bookings: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch users.' });
  }
};

// ══════════════════════════════════════
// UPDATE USER STATUS (approve / disable / enable)
// PATCH /api/admin/users/:id/status
// ══════════════════════════════════════
exports.updateUserStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const validStatuses = ['ACTIVE', 'DISABLED', 'SUSPENDED', 'PENDING'];

    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` });
    }

    // Cannot disable another admin
    const target = await prisma.user.findUnique({ where: { id: req.params.id } });
    if (!target) return res.status(404).json({ error: 'User not found.' });
    if (target.role === 'ADMIN' && req.user.userId !== target.id) {
      return res.status(403).json({ error: 'Cannot change another admin\'s status.' });
    }

    const user = await prisma.user.update({
      where: { id: req.params.id },
      data:  { status },
    });

    // If approved, send email notification
    if (status === 'ACTIVE' && target.status === 'PENDING') {
      emailService.sendAccountApprovedEmail(user).catch(console.error);
    }

    auditService.log({
      action: 'ADMIN_USER_STATUS_CHANGE',
      userId: req.user.userId,
      req,
      meta:   { targetUserId: req.params.id, newStatus: status },
    });

    res.json(user);
  } catch (err) {
    console.error('Update user status error:', err);
    res.status(500).json({ error: 'Failed to update user status.' });
  }
};

// ══════════════════════════════════════
// GET ALL BOOKINGS
// GET /api/admin/bookings
// ══════════════════════════════════════
exports.getAllBookings = async (req, res) => {
  try {
    const { status, category, date } = req.query;

    const where = {};
    if (status)   where.status   = status.toUpperCase();
    if (category) where.category = category.toUpperCase();
    if (date)     where.slot     = { date: new Date(date) };

    const bookings = await prisma.booking.findMany({
      where,
      include: {
        user: { select: { name: true, email: true, memberId: true, regiment: true } },
        slot: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json(bookings);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch bookings.' });
  }
};

// ══════════════════════════════════════
// GET DASHBOARD STATS
// GET /api/admin/stats
// ══════════════════════════════════════
exports.getStats = async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);

    const [
      totalUsers,
      pendingUsers,
      totalBookings,
      todayBookings,
      activeTokens,
      todaySlotStats,
    ] = await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { status: 'PENDING' } }),
      prisma.booking.count(),
      prisma.booking.count({ where: { slot: { date: { gte: today, lt: tomorrow } } } }),
      prisma.booking.count({ where: { status: 'ACTIVE' } }),
      prisma.slot.aggregate({
        where:   { date: { gte: today, lt: tomorrow } },
        _sum:    { capacity: true, booked: true },
      }),
    ]);

    const totalCap    = todaySlotStats._sum.capacity || 0;
    const totalBooked = todaySlotStats._sum.booked   || 0;
    const fillRate    = totalCap ? Math.round((totalBooked / totalCap) * 100) : 0;

    res.json({
      totalUsers,
      pendingUsers,
      totalBookings,
      todayBookings,
      activeTokens,
      todaySlots: { capacity: totalCap, booked: totalBooked, fillRate },
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats.' });
  }
};
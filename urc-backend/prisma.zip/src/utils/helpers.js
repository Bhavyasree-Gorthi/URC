// Token generators, formatters, helpers placeholder
exports.now = () => new Date().toISOString();

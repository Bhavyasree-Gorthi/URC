// // Prisma client singleton placeholder
// module.exports = {};

// src/utils/prisma.js
// Single Prisma client instance shared across the whole app
// Never create "new PrismaClient()" anywhere else

const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient({
  log: process.env.NODE_ENV === 'development'
    ? ['query', 'info', 'warn', 'error']
    : ['error'],
});

module.exports = prisma;
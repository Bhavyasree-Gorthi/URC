// // Email service placeholder
// exports.send = async (to, subject, body) => { return true; };

// src/services/email.service.js
// All email templates and sending functions

const transporter = require('../config/email');

// ── Shared HTML wrapper for all emails ─────────────────────────
const wrap = (bodyHtml) => `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body        { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 20px; }
    .container  { max-width: 520px; margin: 0 auto; background: #fff; border-radius: 16px;
                  overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.1); }
    .header     { background: linear-gradient(135deg, #1F3D2B, #2d5a3d);
                  padding: 28px 24px; text-align: center; }
    .header h1  { color: #fff; margin: 0; font-size: 20px; letter-spacing: 0.5px; }
    .header p   { color: #c9a84c; margin: 6px 0 0; font-size: 12px; }
    .body       { padding: 30px 28px; }
    .body h2    { color: #1F3D2B; margin-top: 0; }
    .btn        { display: inline-block; background: #1F3D2B; color: #fff !important;
                  text-decoration: none; padding: 14px 32px; border-radius: 10px;
                  font-weight: bold; font-size: 15px; margin: 20px 0; }
    .info-table { width: 100%; border-collapse: collapse; margin: 16px 0; }
    .info-table td { padding: 10px 12px; font-size: 14px; }
    .info-table tr:nth-child(odd) td { background: #f0fdf4; }
    .note       { font-size: 12px; color: #999; margin-top: 18px; line-height: 1.6; }
    .footer     { background: #f9f9f9; padding: 14px 20px; text-align: center;
                  font-size: 11px; color: #aaa; border-top: 1px solid #e5e7eb; }
    .badge      { display: inline-block; background: #dcfce7; color: #166534;
                  padding: 3px 10px; border-radius: 20px; font-size: 12px;
                  font-weight: bold; margin-bottom: 16px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>4213 URC NCC GROUP</h1>
      <p>Unit Run Canteen · Kurnool · urckurnool.in</p>
    </div>
    <div class="body">${bodyHtml}</div>
    <div class="footer">
      © 4213 URC NCC Group, Kurnool &nbsp;·&nbsp; urckurnool.in<br>
      This email was sent because you have an account on our canteen booking system.
    </div>
  </div>
</body>
</html>`;

// ── 1. Email Verification ───────────────────────────────────────
exports.sendVerificationEmail = async (user, rawToken) => {
  const url = `${process.env.FRONTEND_URL}/verify-email?token=${rawToken}`;

  const body = `
    <div class="badge">📧 Email Verification</div>
    <h2>Verify Your Email Address</h2>
    <p>Hello <strong>${user.name}</strong>,</p>
    <p>
      Thank you for registering at the URC NCC Kurnool Canteen Booking System.
      Please click the button below to verify your email address and activate your account.
    </p>
    <div style="text-align: center;">
      <a href="${url}" class="btn">✓ Verify My Email</a>
    </div>
    <p class="note">
      This link will expire in <strong>24 hours</strong>.<br>
      If you did not register, please ignore this email — your email will not be added.<br>
      Do not share this link with anyone.
    </p>`;

  await transporter.sendMail({
    from:    process.env.EMAIL_FROM,
    to:      user.email,
    subject: '✓ Verify your email — URC NCC Kurnool Canteen',
    html:    wrap(body),
  });
};

// ── 2. Password Reset ───────────────────────────────────────────
exports.sendPasswordResetEmail = async (user, rawToken) => {
  const url  = `${process.env.FRONTEND_URL}/reset-password?token=${rawToken}`;
  const mins = process.env.RESET_TOKEN_EXPIRES_MINS || '30';

  const body = `
    <div class="badge">🔑 Password Reset</div>
    <h2>Reset Your Password</h2>
    <p>Hello <strong>${user.name}</strong>,</p>
    <p>
      We received a request to reset the password for your URC NCC Canteen account.
      Click the button below to set a new password.
    </p>
    <div style="text-align: center;">
      <a href="${url}" class="btn">🔑 Reset My Password</a>
    </div>
    <p class="note">
      This link will expire in <strong>${mins} minutes</strong>.<br>
      If you did not request a password reset, your account is safe — please ignore this email.<br>
      For security, this link can only be used once.
    </p>`;

  await transporter.sendMail({
    from:    process.env.EMAIL_FROM,
    to:      user.email,
    subject: '🔑 Password Reset Request — URC NCC Kurnool Canteen',
    html:    wrap(body),
  });
};

// ── 3. Booking Confirmation ─────────────────────────────────────
exports.sendBookingConfirmation = async (user, booking, slot) => {
  const dateStr = new Date(slot.date).toLocaleDateString('en-IN', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  });

  const body = `
    <div class="badge">🎫 Booking Confirmed</div>
    <h2>Your Canteen Slot is Booked!</h2>
    <p>Hello <strong>${user.name}</strong>,</p>
    <p>Your canteen slot has been successfully booked. Here are your booking details:</p>
    <table class="info-table">
      <tr><td><strong>Token Number</strong></td><td><strong style="color:#1F3D2B;font-size:18px">${booking.tokenNo}</strong></td></tr>
      <tr><td><strong>Category</strong></td>    <td>${booking.category.replace(/_/g, ' ')}</td></tr>
      <tr><td><strong>Date</strong></td>        <td>${dateStr}</td></tr>
      <tr><td><strong>Time</strong></td>        <td>${slot.time}</td></tr>
      <tr><td><strong>Member ID</strong></td>   <td>${user.memberId || user.id}</td></tr>
    </table>
    <p>
      <strong>Please show this token number at the canteen gate.</strong>
    </p>
    <p class="note">
      To cancel this booking, log in to your account at ${process.env.FRONTEND_URL}.<br>
      For any issues, contact the canteen manager.
    </p>`;

  await transporter.sendMail({
    from:    process.env.EMAIL_FROM,
    to:      user.email,
    subject: `🎫 Booking Confirmed — ${booking.tokenNo} | URC NCC Canteen`,
    html:    wrap(body),
  });
};

// ── 4. Account Approved (by admin) ─────────────────────────────
exports.sendAccountApprovedEmail = async (user) => {
  const body = `
    <div class="badge">✅ Account Approved</div>
    <h2>Your Account Has Been Approved!</h2>
    <p>Hello <strong>${user.name}</strong>,</p>
    <p>
      Great news! Your URC NCC Kurnool Canteen account has been approved by the administrator.
      You can now log in and start booking your canteen slots.
    </p>
    <div style="text-align: center;">
      <a href="${process.env.FRONTEND_URL}" class="btn">→ Login Now</a>
    </div>
    <table class="info-table">
      <tr><td><strong>Member ID</strong></td>  <td>${user.memberId}</td></tr>
      <tr><td><strong>Regiment</strong></td>   <td>${user.regiment}</td></tr>
      <tr><td><strong>Email</strong></td>      <td>${user.email}</td></tr>
    </table>
    <p class="note">
      Keep your Member ID handy — you may need it at the canteen gate.
    </p>`;

  await transporter.sendMail({
    from:    process.env.EMAIL_FROM,
    to:      user.email,
    subject: '✅ Account Approved — URC NCC Kurnool Canteen',
    html:    wrap(body),
  });
};

// ── 5. Booking Cancelled ────────────────────────────────────────
exports.sendBookingCancelledEmail = async (user, booking, slot) => {
  const body = `
    <div class="badge" style="background:#fee2e2;color:#991b1b;">❌ Booking Cancelled</div>
    <h2>Your Booking Has Been Cancelled</h2>
    <p>Hello <strong>${user.name}</strong>,</p>
    <p>Your canteen booking has been cancelled. Details below:</p>
    <table class="info-table">
      <tr><td><strong>Token Number</strong></td><td>${booking.tokenNo}</td></tr>
      <tr><td><strong>Category</strong></td>    <td>${booking.category.replace(/_/g, ' ')}</td></tr>
      <tr><td><strong>Date</strong></td>        <td>${slot.date}</td></tr>
      <tr><td><strong>Time</strong></td>        <td>${slot.time}</td></tr>
    </table>
    <p class="note">
      If you did not cancel this booking, please contact the canteen manager immediately.<br>
      You can make a new booking at ${process.env.FRONTEND_URL}.
    </p>`;

  await transporter.sendMail({
    from:    process.env.EMAIL_FROM,
    to:      user.email,
    subject: `❌ Booking Cancelled — ${booking.tokenNo} | URC NCC Canteen`,
    html:    wrap(body),
  });
};
// // Token service placeholder
// exports.generate = () => 'token';

// src/services/token.service.js
// Creates and verifies JWT access tokens + refresh tokens

const jwt    = require('jsonwebtoken');
const crypto = require('crypto');
const prisma = require('../utils/prisma');

// ── Generate both tokens and save refresh token to DB ──────────
exports.generateTokenPair = async (user, req) => {
  const payload = {
    userId: user.id,
    role:   user.role,
    email:  user.email,
  };

  // Short-lived access token (15 minutes)
  const accessToken = jwt.sign(
    payload,
    process.env.JWT_ACCESS_SECRET,
    { expiresIn: process.env.JWT_ACCESS_EXPIRES || '15m' }
  );

  // Long-lived refresh token (random, stored in DB)
  const refreshToken = crypto.randomBytes(40).toString('hex');

  // Save refresh token to sessions table
  await prisma.session.create({
    data: {
      userId:       user.id,
      refreshToken,
      ipAddress:    req?.ip || 'unknown',
      userAgent:    req?.get('user-agent') || 'unknown',
      expiresAt:    new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
    },
  });

  return { accessToken, refreshToken };
};

// ── Create new access token from a valid refresh token ─────────
exports.refreshAccessToken = async (refreshToken) => {
  const session = await prisma.session.findUnique({
    where:   { refreshToken },
    include: { user: true },
  });

  if (!session) {
    throw new Error('Refresh token not found');
  }

  if (session.expiresAt < new Date()) {
    // Clean up expired session
    await prisma.session.delete({ where: { id: session.id } });
    throw new Error('Refresh token expired');
  }

  // Create new access token
  const newAccessToken = jwt.sign(
    { userId: session.user.id, role: session.user.role, email: session.user.email },
    process.env.JWT_ACCESS_SECRET,
    { expiresIn: process.env.JWT_ACCESS_EXPIRES || '15m' }
  );

  return newAccessToken;
};
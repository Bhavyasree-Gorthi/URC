// // Audit/log helper placeholder
// exports.log = (msg) => console.log(msg);

// src/services/audit.service.js
// Logs every important action to the console (extend to DB later)

exports.log = ({ action, userId = null, req = null, success = true, meta = {} }) => {
  const entry = {
    time:      new Date().toISOString(),
    action,
    userId,
    ip:        req?.ip || 'unknown',
    userAgent: req?.get('user-agent') || 'unknown',
    success,
    ...meta,
  };
  if (success) {
    console.log(`[AUDIT] ✅ ${action}`, entry);
  } else {
    console.warn(`[AUDIT] ❌ ${action}`, entry);
  }
};
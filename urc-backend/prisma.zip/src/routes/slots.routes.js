// // /api/slots routes placeholder
// const express = require('express');
// const router = express.Router();

// router.get('/', (req, res) => res.json([]));

// module.exports = router;


// src/routes/slots.routes.js

const router = require('express').Router();
const ctrl   = require('../controllers/slots.controller');
const { authenticate } = require('../middleware/auth');

// Get slots for next 14 days (logged-in users)
router.get('/upcoming', authenticate, ctrl.getUpcomingSlots);

// Get slots (optionally filter by ?date=YYYY-MM-DD)
router.get('/', authenticate, ctrl.getSlots);

module.exports = router;
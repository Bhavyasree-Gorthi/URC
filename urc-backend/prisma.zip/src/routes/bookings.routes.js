// // /api/bookings routes placeholder
// const express = require('express');
// const router = express.Router();

// router.post('/', (req, res) => res.json({}));

// module.exports = router;
// // src/routes/bookings.routes.js

// const router = require('express').Router();
// const ctrl   = require('../controllers/bookings.controller');
// const { authenticate } = require('../middleware/auth');
// const { validateCreateBooking } = require('../middleware/validate');

// // Get current user's bookings
// router.get('/mine', authenticate, ctrl.getMyBookings);

// // Create a new booking
// router.post('/', authenticate, validateCreateBooking, ctrl.createBooking);

// // Cancel a booking
// router.patch('/:id/cancel', authenticate, ctrl.cancelBooking);

// module.exports = router;

// src/routes/bookings.routes.js

const router = require('express').Router();
const ctrl   = require('../controllers/bookings.controller');
const { authenticate } = require('../middleware/auth');
const { validateCreateBooking } = require('../middleware/validate');

// Get current user's bookings
router.get('/mine', authenticate, ctrl.getMyBookings);

// Create a new booking
router.post('/', authenticate, validateCreateBooking, ctrl.createBooking);

// Cancel a booking
router.patch('/:id/cancel', authenticate, ctrl.cancelBooking);

module.exports = router;
// // /api/admin routes placeholder
// const express = require('express');
// const router = express.Router();

// router.get('/stats', (req, res) => res.json({}));

// module.exports = router;

// src/routes/admin.routes.js
// All routes here require authentication + ADMIN role

const router     = require('express').Router();
const adminCtrl  = require('../controllers/admin.controller');
const slotsCtrl  = require('../controllers/slots.controller');
const bkCtrl     = require('../controllers/bookings.controller');
const { authenticate, requireAdmin } = require('../middleware/auth');

// Apply auth + admin check to ALL routes in this file
router.use(authenticate, requireAdmin);

// ── Dashboard stats
router.get('/stats',                    adminCtrl.getStats);

// ── Users
router.get('/users',                    adminCtrl.getAllUsers);
router.patch('/users/:id/status',       adminCtrl.updateUserStatus);

// ── Slots
router.get('/slots',                    slotsCtrl.getSlots);
router.put('/slots/:id',                slotsCtrl.updateSlot);
router.post('/slots/generate',          slotsCtrl.generateSlots);

// ── Bookings
router.get('/bookings',                 adminCtrl.getAllBookings);
router.patch('/bookings/:id/cancel',    bkCtrl.cancelBooking);

module.exports = router;
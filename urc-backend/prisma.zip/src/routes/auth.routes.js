// // /api/auth routes placeholder
// const express = require('express');
// const router = express.Router();

// router.post('/login', (req, res) => res.json({}));

// module.exports = router;

// src/routes/auth.routes.js

const router = require('express').Router();
const ctrl   = require('../controllers/auth.controller');
const { authLimiter, registerLimiter, resetLimiter } = require('../middleware/rateLimiter');
const { validateRegister, validateLogin, validateResetPassword } = require('../middleware/validate');
const { authenticate } = require('../middleware/auth');

router.post('/register',              registerLimiter, validateRegister,       ctrl.register);
router.post('/login',                 authLimiter,     validateLogin,          ctrl.login);
router.post('/logout',                authenticate,                            ctrl.logout);
router.post('/refresh-token',                                                  ctrl.refreshToken);
router.get ('/verify-email/:token',                                            ctrl.verifyEmail);
router.post('/resend-verification',   authLimiter,                             ctrl.resendVerification);
router.post('/forgot-password',       resetLimiter,                            ctrl.forgotPassword);
router.post('/reset-password/:token',              validateResetPassword,      ctrl.resetPassword);

module.exports = router;